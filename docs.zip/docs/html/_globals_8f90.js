var _globals_8f90 =
[
    [ "logic_to_double", "_globals_8f90.html#ac07f59ca2367e0a3dcc7b983d391b678", null ],
    [ "dp", "_globals_8f90.html#a27ebca0b1a70249236b0fdf4197cf138", null ],
    [ "max_num_years", "_globals_8f90.html#ab71bb66649a2f725e4087ef4d7eca398", null ],
    [ "max_size_class", "_globals_8f90.html#a8afbf0a10c6378df266350f1177a1160", null ],
    [ "max_size_mm", "_globals_8f90.html#a202bc1295ee17d618eddbe02c00f83f9", null ],
    [ "meters_per_naut_mile", "_globals_8f90.html#ab00ceb3bb10bc81cf88c86d34dfd5f2f", null ],
    [ "min_size_mm", "_globals_8f90.html#a1d54c47d8fba383dc41761ee4a761ca3", null ],
    [ "qp", "_globals_8f90.html#a1817835b1b7fe899c06c8d8b9d40c09c", null ],
    [ "read_dev", "_globals_8f90.html#a803bc75e270c2d231a6f3babf5bf5d76", null ],
    [ "sp", "_globals_8f90.html#a3d22a2ec0cbd3991954e19fe33cf8925", null ],
    [ "term_blk", "_globals_8f90.html#ac4ef36b22624591934c84d75baeade1e", null ],
    [ "term_blu", "_globals_8f90.html#a371a7e55ceb93dde52f1806392e71a03", null ],
    [ "term_red", "_globals_8f90.html#add1d361da8ff0e859431729d6628e742", null ],
    [ "term_yel", "_globals_8f90.html#a3d34ab77443c80b405739ba2a337e01e", null ],
    [ "write_dev", "_globals_8f90.html#a4fdd7f82751e41d4cc7ad9bc73ee8923", null ]
];