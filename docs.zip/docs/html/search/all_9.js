var searchData=
[
  ['k_5fmu_0',['k_mu',['../structgrowth__mod_1_1growth__struct.html#a0a8f6dc6165befcee540d7d6876a176f',1,'growth_mod::growth_struct']]],
  ['k_5fsd_1',['k_sd',['../structgrowth__mod_1_1growth__struct.html#a179a75919547fbec0c85d69c3d2feeff',1,'growth_mod::growth_struct']]]
];
