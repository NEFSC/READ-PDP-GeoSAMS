var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuwxyz",
  1: "dgmr",
  2: "dgmor",
  3: "adfgis",
  4: "aceghilmnrstw",
  5: "abcdefgiklmnoqrstuwxyz",
  6: "dps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

