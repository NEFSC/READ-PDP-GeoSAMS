var searchData=
[
  ['write_5fdev_0',['write_dev',['../namespaceglobals.html#a4fdd7f82751e41d4cc7ad9bc73ee8923',1,'globals']]]
];
