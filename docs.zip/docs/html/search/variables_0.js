var searchData=
[
  ['a_0',['a',['../structmortality__mod_1_1mortality__struct.html#a9766c39fb18ba4d28851979c91e7e927',1,'mortality_mod::mortality_struct']]],
  ['alpha_1',['alpha',['../structmortality__mod_1_1mortality__struct.html#ad706f8e4ceefce61a6ec54b94a085f8b',1,'mortality_mod::mortality_struct']]],
  ['area_2',['area',['../structdata__point__mod_1_1data__point__struct.html#a82aa9de4acedbbd16a00557b3d70c561',1,'data_point_mod::data_point_struct']]]
];
