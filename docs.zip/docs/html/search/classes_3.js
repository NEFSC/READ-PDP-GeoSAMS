var searchData=
[
  ['recruit_5fstruct_0',['recruit_struct',['../structrecruit__mod_1_1recruit__struct.html',1,'recruit_mod']]]
];
