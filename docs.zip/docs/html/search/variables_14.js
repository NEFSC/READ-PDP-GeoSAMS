var searchData=
[
  ['y_0',['y',['../structdata__point__mod_1_1data__point__struct.html#a8496a38586643131be817890cf82dbbf',1,'data_point_mod::data_point_struct']]],
  ['year_1',['year',['../structmortality__mod_1_1mortality__struct.html#a934402446946de2a550940b06114615b',1,'mortality_mod::mortality_struct::year'],['../structrecruit__mod_1_1recruit__struct.html#ad59683d4de352ef4e18cafc9fe0d3f51',1,'recruit_mod::recruit_struct::year']]]
];
