var searchData=
[
  ['b_0',['b',['../structmortality__mod_1_1mortality__struct.html#a10cb19ceab63d82c7f3992db82f8dcf2',1,'mortality_mod::mortality_struct']]]
];
