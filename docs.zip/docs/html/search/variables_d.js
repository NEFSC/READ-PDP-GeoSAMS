var searchData=
[
  ['qp_0',['qp',['../namespaceglobals.html#a1817835b1b7fe899c06c8d8b9d40c09c',1,'globals']]]
];
