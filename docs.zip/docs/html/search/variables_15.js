var searchData=
[
  ['z_0',['z',['../structdata__point__mod_1_1data__point__struct.html#a36a9c26170a7ef2060f1306fc27b90ec',1,'data_point_mod::data_point_struct']]]
];
