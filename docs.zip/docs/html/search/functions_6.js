var searchData=
[
  ['load_5fdata_0',['load_data',['../_i_o_routines_8f90.html#a893bac6622653417c14a5cbf187dd9b2',1,'IORoutines.f90']]],
  ['load_5fgrid_1',['load_grid',['../_i_o_routines_8f90.html#aeff9e35f42d1643d5296e8941e79fe3d',1,'IORoutines.f90']]],
  ['logic_5fto_5fdouble_2',['logic_to_double',['../namespaceglobals.html#ac07f59ca2367e0a3dcc7b983d391b678',1,'globals']]]
];
