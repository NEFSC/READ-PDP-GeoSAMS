var searchData=
[
  ['term_5fblk_0',['term_blk',['../namespaceglobals.html#ac4ef36b22624591934c84d75baeade1e',1,'globals']]],
  ['term_5fblu_1',['term_blu',['../namespaceglobals.html#a371a7e55ceb93dde52f1806392e71a03',1,'globals']]],
  ['term_5fred_2',['term_red',['../namespaceglobals.html#add1d361da8ff0e859431729d6628e742',1,'globals']]],
  ['term_5fyel_3',['term_yel',['../namespaceglobals.html#a3d34ab77443c80b405739ba2a337e01e',1,'globals']]]
];
