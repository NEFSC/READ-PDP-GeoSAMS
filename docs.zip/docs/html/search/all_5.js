var searchData=
[
  ['fishing_5feffort_0',['fishing_effort',['../structmortality__mod_1_1mortality__struct.html#a2c92d193ca81f152627a9be7bdbb2c26',1,'mortality_mod::mortality_struct']]],
  ['fishingroutines_2ef90_1',['FishingRoutines.f90',['../_fishing_routines_8f90.html',1,'']]]
];
