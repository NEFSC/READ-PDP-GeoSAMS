var searchData=
[
  ['d_0',['d',['../structmortality__mod_1_1mortality__struct.html#a990100d177d1e2f55955adee0d25d45c',1,'mortality_mod::mortality_struct']]],
  ['discard_1',['discard',['../structmortality__mod_1_1mortality__struct.html#ace1245bd72ac02f9deba4536496810a3',1,'mortality_mod::mortality_struct']]],
  ['dp_2',['dp',['../namespaceglobals.html#a27ebca0b1a70249236b0fdf4197cf138',1,'globals']]]
];
