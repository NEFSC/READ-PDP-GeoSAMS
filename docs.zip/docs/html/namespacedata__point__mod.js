var namespacedata__point__mod =
[
    [ "data_point_struct", "structdata__point__mod_1_1data__point__struct.html", "structdata__point__mod_1_1data__point__struct" ],
    [ "num_dimensions", "namespacedata__point__mod.html#a6c963151157172987880d2c34c3d0f1d", null ]
];