var _scallop_mortality_8f90 =
[
    [ "mortality_mod::mortality_struct", "structmortality__mod_1_1mortality__struct.html", "structmortality__mod_1_1mortality__struct" ],
    [ "ring_size_selectivity", "_scallop_mortality_8f90.html#ad441ad5ef369deaea9f3720c73489c7f", null ],
    [ "setmortality", "_scallop_mortality_8f90.html#ac80ecd37c436c3ad6da3db69a57b28a4", null ]
];