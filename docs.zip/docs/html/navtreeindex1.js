var NAVTREEINDEX1 =
{
"structrecruit__mod_1_1recruit__struct.html#a819dedf4c6fdbadc60c7c4f7d31a7fe1":[1,0,5,0,1],
"structrecruit__mod_1_1recruit__struct.html#a819dedf4c6fdbadc60c7c4f7d31a7fe1":[2,0,3,0,1],
"structrecruit__mod_1_1recruit__struct.html#ad59683d4de352ef4e18cafc9fe0d3f51":[2,0,3,0,5],
"structrecruit__mod_1_1recruit__struct.html#ad59683d4de352ef4e18cafc9fe0d3f51":[1,0,5,0,5]
};
