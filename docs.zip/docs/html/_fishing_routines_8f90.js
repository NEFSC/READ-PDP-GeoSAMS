var _fishing_routines_8f90 =
[
    [ "cash_money", "_fishing_routines_8f90.html#a27ac6aaa17c45c72c15b4b07b24949a1", null ],
    [ "get_total_catch", "_fishing_routines_8f90.html#a08822020edde345ad55cbe1f3eead0f2", null ],
    [ "scallops_to_counts", "_fishing_routines_8f90.html#a70ea1a06f2da4b6f5c15711394317856", null ],
    [ "set_fish_effort_wgt_usd_clop", "_fishing_routines_8f90.html#a5c228b2fa4afcfca17723f670303576c", null ],
    [ "set_fish_effort_wgt_x", "_fishing_routines_8f90.html#adc9b8ad81c5fd94e3c8ca472c5ccdd79", null ],
    [ "set_fish_effort_wgt_x_clop", "_fishing_routines_8f90.html#aa06b80eff75fd0f06b789a7490173fdf", null ],
    [ "set_fishing", "_fishing_routines_8f90.html#a1815816dba9e73005c954e604b234bbe", null ],
    [ "set_fishing_effort_weight_usd", "_fishing_routines_8f90.html#a6f22ffae6b974c0a7e0c2adbb1610e42", null ]
];