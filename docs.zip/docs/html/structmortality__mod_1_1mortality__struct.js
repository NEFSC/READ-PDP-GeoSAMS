var structmortality__mod_1_1mortality__struct =
[
    [ "a", "structmortality__mod_1_1mortality__struct.html#a9766c39fb18ba4d28851979c91e7e927", null ],
    [ "alpha", "structmortality__mod_1_1mortality__struct.html#ad706f8e4ceefce61a6ec54b94a085f8b", null ],
    [ "b", "structmortality__mod_1_1mortality__struct.html#a10cb19ceab63d82c7f3992db82f8dcf2", null ],
    [ "c", "structmortality__mod_1_1mortality__struct.html#a13e686103a94e0fc98faaba36ea3201b", null ],
    [ "d", "structmortality__mod_1_1mortality__struct.html#a990100d177d1e2f55955adee0d25d45c", null ],
    [ "discard", "structmortality__mod_1_1mortality__struct.html#ace1245bd72ac02f9deba4536496810a3", null ],
    [ "fishing_effort", "structmortality__mod_1_1mortality__struct.html#a2c92d193ca81f152627a9be7bdbb2c26", null ],
    [ "incidental", "structmortality__mod_1_1mortality__struct.html#a13ddab7f4dedaad6ae03a5b15f0ce2ca", null ],
    [ "is_closed", "structmortality__mod_1_1mortality__struct.html#adf7194ebaca337d45b64db731d6f98cc", null ],
    [ "management_area", "structmortality__mod_1_1mortality__struct.html#a3d1e4fd0fb91ea1a1e2b04ceecbe21ec", null ],
    [ "natural_mort_adult", "structmortality__mod_1_1mortality__struct.html#a11abb48e344c9dd6f6e3381937bbe6b1", null ],
    [ "natural_mort_juv", "structmortality__mod_1_1mortality__struct.html#a54effb883b00f40d2982211ca0788607", null ],
    [ "natural_mortality", "structmortality__mod_1_1mortality__struct.html#aabcb437bc97b2e97a658f2083f92e028", null ],
    [ "num_size_classes", "structmortality__mod_1_1mortality__struct.html#ae374cdfe5dd9e8a27be68b2d05e154e9", null ],
    [ "num_years", "structmortality__mod_1_1mortality__struct.html#a48ebf63d225c636eda7ae387c281e2a4", null ],
    [ "region", "structmortality__mod_1_1mortality__struct.html#a918a470ad1f17c5ce46b9d61f9fa131e", null ],
    [ "select", "structmortality__mod_1_1mortality__struct.html#a11e3249fcfcbf5b445488eaaf8ee2ec7", null ],
    [ "year", "structmortality__mod_1_1mortality__struct.html#a934402446946de2a550940b06114615b", null ]
];