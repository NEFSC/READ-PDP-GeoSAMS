var structrecruit__mod_1_1recruit__struct =
[
    [ "max_rec_ind", "structrecruit__mod_1_1recruit__struct.html#a3a0f37328775c0a58ac966e2644a4e17", null ],
    [ "n_year", "structrecruit__mod_1_1recruit__struct.html#a819dedf4c6fdbadc60c7c4f7d31a7fe1", null ],
    [ "rec_start", "structrecruit__mod_1_1recruit__struct.html#a1df6c22eea310416cc19f0a8228c35f2", null ],
    [ "rec_stop", "structrecruit__mod_1_1recruit__struct.html#a3123b0161681d340d162fcaaa72a124b", null ],
    [ "recruitment", "structrecruit__mod_1_1recruit__struct.html#a094eb3b56e5dc5bc0e9214e0a6b228c7", null ],
    [ "year", "structrecruit__mod_1_1recruit__struct.html#ad59683d4de352ef4e18cafc9fe0d3f51", null ]
];