var _scallop_output_8f90 =
[
    [ "scallop_output", "_scallop_output_8f90.html#a72cecbcdf98b04ec799105dfb1650adb", null ],
    [ "scallop_output_region", "_scallop_output_8f90.html#a614fc40bc0c293d56c15966f65b7be66", null ],
    [ "output_dir", "_scallop_output_8f90.html#a24bfca0cf6a387943ae9d1e66b0ae611", null ]
];